package com.example.demoMysqlApi.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {
	
	@Id
	private int sid;
	private String sname;
	private String scollege;
	private String address;

	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getScollege() {
		return scollege;
	}
	public void setScollege(String scollege) {
		this.scollege = scollege;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String saddress) {
		this.address = saddress;
	}
	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", scollege=" + scollege + ", saddress=" + address
				+ ", getSid()=" + getSid() + ", getSname()=" + getSname() + ", getScollege()=" + getScollege()
				+ ", getSaddress()=" + getAddress() + "]";
	}
	
	
	
	
}
